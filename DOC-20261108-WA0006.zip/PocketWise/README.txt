PocketWise - Android WebView project

HOW TO BUILD THE APK
1. Install Android Studio (https://developer.android.com/studio).
2. File > Open > select this "PocketWise" folder. Wait for Gradle sync.
3. Run on a phone/emulator with the green Run button, or build an APK:
   Build > Build Bundle(s) / APK(s) > Build APK(s)
   (Output: app/build/outputs/apk/debug/app-debug.apk)

For Play Store release: Build > Generate Signed Bundle / APK.

TO UPDATE THE APP
Replace app/src/main/assets/index.html with your new file and rebuild.
Change the app name in app/src/main/res/values/strings.xml
and the package id (applicationId) in app/build.gradle.kts.
